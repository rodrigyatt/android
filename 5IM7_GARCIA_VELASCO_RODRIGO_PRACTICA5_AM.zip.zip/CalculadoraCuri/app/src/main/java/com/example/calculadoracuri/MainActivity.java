package com.example.calculadoracuri;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;
//García Espino Enrique Román
//García Velasco Rodrigo

public class MainActivity extends AppCompatActivity {
    private EditText num1;

    private CheckBox checkF;
    private CheckBox checkK;
    private CheckBox checkR;

    private TextView resultado1;
    private TextView resultado2;
    private TextView resultado3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);

        num1 = (EditText) this.findViewById(R.id.num1);

        checkF = (CheckBox) this.findViewById(R.id.checkF);
        checkK = (CheckBox) this.findViewById(R.id.checkK);
        checkR = (CheckBox) this.findViewById(R.id.checkR);

        resultado1 = (TextView) this.findViewById(R.id.resultado1);
        resultado2 = (TextView) this.findViewById(R.id.resultado2);
        resultado3 = (TextView) this.findViewById(R.id.resultado3);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void limpiar(View view) {
        num1.setText("");

        checkF.setChecked(false);
        checkK.setChecked(false);
        checkR.setChecked(false);

        resultado1.setText("");
        resultado2.setText("");
        resultado3.setText("");
    }

    public void calcular(View view) {
        String numStr = num1.getText().toString();
        System.out.println(numStr);
        if (numStr.isEmpty()) {
            Toast.makeText(this, "El número no puede estar vacío", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            float num = Float.parseFloat(numStr);

            boolean isF = checkF.isChecked();
            boolean isK = checkK.isChecked();
            boolean isR = checkR.isChecked();

            if (!(isF || isK || isR)) {
                Toast.makeText(this, "Tienes que seleccionar una opción", Toast.LENGTH_SHORT).show();
                return;
            }


            String plantilla = "Equivale a  %.2f grados %s.";

            if (isF) {
                resultado1.setText(String.format(Locale.getDefault(), plantilla, (num * 9 / 5) + 32, "Fahrenheit"));
            }
            if (isK) {
                resultado2.setText(String.format(Locale.getDefault(), plantilla, num + 273.15, "Kelvin"));
            }

            if (isR) {
                resultado3.setText(String.format(Locale.getDefault(), plantilla, (num * 9 / 5) + 491.67, "Rankine"));
            }


        } catch (NumberFormatException e) {
            Toast.makeText(this, "Error al convertir a número", Toast.LENGTH_SHORT).show();
        }


    }
}
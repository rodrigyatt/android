package com.example.imagenesybotones;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


/*
García Espino Enrique Román
García Velasco Rodrigo
*/
public class MainActivity extends AppCompatActivity {

    boolean activo;
    ImageView imagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        activo = true;
        imagen = findViewById(R.id.imageView);
    }


    public void boton1(View view) {
        cambiarImagen(1, view);
    }

    public void boton2(View view) {
        cambiarImagen(2, view);
    }

    public void boton3(View view) {
        cambiarImagen(3, view);
    }

    public void boton4(View view) {
        cambiarImagen(4, view);
    }

    public void boton5(View view) {
        cambiarImagen(5, view);
    }

    public void boton6(View view) {
        cambiarImagen(6, view);
    }


    private void cambiarImagen(int i, View view) {
        if (!activo) {
            return;
        }
        switch (i) {
            case 1:
                imagen.setImageResource(R.drawable.sin_t_tulo);
                break;
            case 2:
                imagen.setImageResource(R.drawable.sin_t_tulo1);
                break;
            case 3:
                imagen.setImageResource(R.drawable.sin_t_tulo2);
                break;
            case 4:
                imagen.setImageResource(R.drawable.sin_t_tulo3);
                break;
            case 5:
                imagen.setImageResource(R.drawable.sin_t_tulo4);
                break;
            case 6:
                imagen.setImageResource(R.drawable.sin_t_tulo5);
                break;
        }
    }

}